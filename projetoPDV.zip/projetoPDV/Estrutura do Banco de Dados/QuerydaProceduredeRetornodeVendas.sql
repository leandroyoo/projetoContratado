create procedure dbo.retorna_grid_vendas_v2
as

set nocount on;
begin
			
 select v.data, 
		c.cpf,
		c.nome as nome_do_Cliente,
		p.codProduto,
		p.nome as nome_do_produto,
		p.preco as preco_do_produto_unit�rio,
		p.quantidade,
	sum(p.quantidade) * sum(p.preco) as total
	from tb_vendas v
	full join  itens_vendas i on
		cVendas = codigoVendas
	full join tb_produtos p on
		cProduto = CodProduto
	full join tb_Cliente c on
		cCliente = cpf
	group by 
			v.data,
			c.cpf,
			c.nome,
			p.codProduto,
			p.nome,	
			p.preco,
			p.quantidade

end