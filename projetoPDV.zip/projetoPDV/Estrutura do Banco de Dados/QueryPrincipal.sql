




Create table tb_Vendas(
   Data		datetime,
   cCliente	int ,---foregueinkeycliente
   CodigoVendas int not null primary key --primary key
);

Create table Itens_Vendas(
    cProduto	int, ---foregueinkey produto
	cVendas		int,  -- foregueinkey vendas
	Produto		varchar(100),
    Quantidade  int,
    Pre�o		float
);


Create table tb_Produtos(
  CodProduto	int not null primary key,
  Nome			varchar(100),
  Preco			float

);

create table tb_Cliente(
	
	CPF		int  NOT NULL PRIMARY KEY, ---primary key vendas
	Nome	varchar(100)
);



ALTER TABLE Itens_vendas
ADD FOREIGN KEY (cProduto) REFERENCES tb_Produtos(codProduto);

ALTER TABLE itens_vendas
ADD FOREIGN KEY (cVendas) REFERENCES tb_Vendas(codigoVendas);

ALTER TABLE tb_vendas
ADD FOREIGN KEY (cCliente) REFERENCES tb_Cliente(cpf);



